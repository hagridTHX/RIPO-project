﻿import pyautogui
import time
import math

class GestureController:
    def __init__(self):
        # Disable fail-safe for uninterrupted gesture control
        pyautogui.FAILSAFE = False
        self.last_gesture = "No gesture"
        self.last_gesture_confidence = 0.0
        self.last_gesture_time = 0
        self.gesture_display_duration = 0.3  # Show gesture for 0.3 seconds
        
        # Debounce setup
        self.last_click_time = 0
        self.click_cooldown = 1.0

        self.last_scroll_time = 0
        self.scroll_cooldown = 0.05 

        self.last_swipe_time = 0
        self.swipe_cooldown = 1.0   
        
        self.last_log_time = 0      
        self.log_cooldown = 1.0 

        self.wrist_history = [] 
    
    def process_landmarks(self, hand_landmarks, gestures, idx, current_time):
        gesture_recognized = ""
        gesture_confidence = 0.0

        # Detect swipes from wrist movement
        wrist_x = hand_landmarks[0].x
        self.wrist_history.append((current_time, wrist_x))
        
        # Keep only recent 0.4 seconds of movement data
        self.wrist_history = [history for history in self.wrist_history if current_time - history[0] < 0.4]

        # Calculate swipe velocity
        if len(self.wrist_history) > 3:
            oldest_time, oldest_x = self.wrist_history[0]
            dx = wrist_x - oldest_x
            dt = current_time - oldest_time
            
            if dt > 0.05:
                velocity = dx / dt
                

                if dx < -0.15 and velocity < -0.6:
                    gesture_recognized = "Left swipe"
                    gesture_confidence = 1.0
                    if current_time - self.last_swipe_time > self.swipe_cooldown:
                        print(f"[{current_time:.1f}] Action: Browser back")
                        pyautogui.hotkey('browserback')
                        self.last_swipe_time = current_time
                    self.wrist_history = [] 
                    
                elif dx > 0.15 and velocity > 0.6:
                    gesture_recognized = "Right swipe"
                    gesture_confidence = 1.0
                    if current_time - self.last_swipe_time > self.swipe_cooldown:
                        print(f"[{current_time:.1f}] Action: Browser forward")
                        pyautogui.hotkey('browserforward')
                        self.last_swipe_time = current_time
                    self.wrist_history = [] 

        # Detect pinch-to-click and thumb gestures
        if gesture_recognized == "":
            thumb_tip = hand_landmarks[4]
            index_tip = hand_landmarks[8]
            distance = math.hypot(thumb_tip.x - index_tip.x, thumb_tip.y - index_tip.y)
            
            if distance < 0.05:
                gesture_recognized = "Click"
                gesture_confidence = 1.0
                if current_time - self.last_click_time > self.click_cooldown:
                    print(f"[{current_time:.1f}] Action: Click")
                    pyautogui.click()
                    self.last_click_time = current_time
            
            elif gestures and len(gestures) > idx:
                top_gesture = gestures[idx][0].category_name
                gesture_confidence = gestures[idx][0].score
                
                # Only display handled gestures
                if top_gesture == "Thumb_Up":
                    gesture_recognized = "Thumb Up"
                    if current_time - self.last_log_time > self.log_cooldown:
                        print(f"[{current_time:.1f}] Action: Scroll up")
                        self.last_log_time = current_time
                    
                    if current_time - self.last_scroll_time > self.scroll_cooldown:
                        pyautogui.scroll(120) 
                        self.last_scroll_time = current_time
                        
                elif top_gesture == "Thumb_Down":
                    gesture_recognized = "Thumb Down"
                    if current_time - self.last_log_time > self.log_cooldown:
                        print(f"[{current_time:.1f}] Action: Scroll down")
                        self.last_log_time = current_time
                    
                    if current_time - self.last_scroll_time > self.scroll_cooldown:
                        pyautogui.scroll(-120) 
                        self.last_scroll_time = current_time
        
        # Store last recognized gesture for display (keeps showing for duration)
        if gesture_recognized:
            self.last_gesture = gesture_recognized
            self.last_gesture_confidence = gesture_confidence
            self.last_gesture_time = current_time
        elif current_time - self.last_gesture_time > self.gesture_display_duration:
            # Clear gesture display after display duration expires
            self.last_gesture = "No gesture"
            self.last_gesture_confidence = 0.0
